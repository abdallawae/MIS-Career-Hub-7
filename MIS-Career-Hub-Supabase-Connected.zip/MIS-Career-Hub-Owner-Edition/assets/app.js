(function(){
 const cfg=window.MIS_SUPABASE_CONFIG||{};
 const ready=cfg.url&&cfg.anonKey&&window.supabase;
 window.sb=ready?window.supabase.createClient(cfg.url,cfg.anonKey):null;
 window.MIS={
  configured:!!ready,
  async user(){if(!window.sb)return null;const {data:{user}}=await sb.auth.getUser();return user},
  async profile(){const u=await this.user();if(!u)return null;const {data}=await sb.from('profiles').select('*').eq('id',u.id).single();return data},
  async signOut(){if(sb)await sb.auth.signOut();location.href='/index.html'},
  async requireUser(){const u=await this.user();if(!u)location.href='/auth.html';return u},
  async guardAdmin(){const u=await this.requireUser();if(!u)return;const p=await this.profile();if(!p||!['owner','admin'].includes(p.role))location.href='/student/dashboard.html';return p},
  msg(t,ok=true){const e=document.getElementById('msg');if(e){e.textContent=t;e.className='notice '+(ok?'ok':'bad')}else alert(t)}
 };
 window.completeLesson=async function(id){if(!sb)return MIS.msg('اربط Supabase أولًا.',false);const u=await MIS.user();if(!u)return location.href='/auth.html';const {error}=await sb.from('lesson_progress').upsert({user_id:u.id,lesson_id:id});MIS.msg(error?error.message:'تم حفظ تقدمك ✓',!error)};
})();
