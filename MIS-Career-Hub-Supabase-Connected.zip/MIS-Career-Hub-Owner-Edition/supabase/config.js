// Public Supabase configuration for MIS Career Hub.
// Never put secret/service_role keys in browser code.
window.MIS_SUPABASE_CONFIG={
  url:"https://airafrdllneuoqgmqgbz.supabase.co",
  anonKey:"sb_publishable_Q9CDs-vCpaNRiWjD20Ds3w_eZAMtwDf"
};
