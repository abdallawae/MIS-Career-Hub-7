-- MIS Career Hub | Production starter schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 avatar_url text,
 phone text,
 role text not null default 'student' check (role in ('student','admin','owner')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.courses (
 id uuid primary key default gen_random_uuid(), slug text unique not null,
 title text not null, description text, level text default 'Beginner',
 published boolean not null default true, created_at timestamptz default now()
);
create table if not exists public.lessons (
 id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
 title text not null, content text, video_url text, position int not null default 1,
 published boolean not null default true, created_at timestamptz default now(), unique(course_id,position)
);
create table if not exists public.enrollments (
 user_id uuid references auth.users(id) on delete cascade,
 course_id uuid references public.courses(id) on delete cascade,
 started_at timestamptz default now(), primary key(user_id,course_id)
);
create table if not exists public.lesson_progress (
 user_id uuid references auth.users(id) on delete cascade,
 lesson_id uuid references public.lessons(id) on delete cascade,
 completed_at timestamptz default now(), primary key(user_id,lesson_id)
);
create table if not exists public.quizzes (
 id uuid primary key default gen_random_uuid(), course_id uuid references public.courses(id) on delete cascade,
 title text not null, pass_score numeric default 60, published boolean default true
);
create table if not exists public.quiz_questions (
 id uuid primary key default gen_random_uuid(), quiz_id uuid references public.quizzes(id) on delete cascade,
 question text not null, options jsonb not null default '[]'::jsonb, correct_index int not null
);
create table if not exists public.quiz_attempts (
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade,
 quiz_id uuid references public.quizzes(id) on delete cascade, score numeric not null,
 attempted_at timestamptz default now()
);
create table if not exists public.certificates (
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade,
 course_id uuid references public.courses(id) on delete cascade,
 certificate_number text unique not null default encode(gen_random_bytes(8),'hex'), issued_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.enrollments enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.certificates enable row level security;

create or replace function public.is_staff() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role in ('owner','admin'));
$$;

-- remove/recreate policies safely
create policy "profiles own" on public.profiles for select using (id=auth.uid() or public.is_staff());
create policy "profiles update own" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
create policy "courses public" on public.courses for select using (published or public.is_staff());
create policy "courses staff write" on public.courses for all using (public.is_staff()) with check (public.is_staff());
create policy "lessons public" on public.lessons for select using (published or public.is_staff());
create policy "lessons staff write" on public.lessons for all using (public.is_staff()) with check (public.is_staff());
create policy "enroll own" on public.enrollments for select using (user_id=auth.uid() or public.is_staff());
create policy "enroll insert own" on public.enrollments for insert with check (user_id=auth.uid());
create policy "progress own" on public.lesson_progress for select using (user_id=auth.uid() or public.is_staff());
create policy "progress insert own" on public.lesson_progress for insert with check (user_id=auth.uid());
create policy "quizzes public" on public.quizzes for select using (published or public.is_staff());
create policy "questions public" on public.quiz_questions for select using (true);
create policy "attempt own" on public.quiz_attempts for select using (user_id=auth.uid() or public.is_staff());
create policy "attempt insert own" on public.quiz_attempts for insert with check (user_id=auth.uid());
create policy "cert own" on public.certificates for select using (user_id=auth.uid() or public.is_staff());

-- Create a profile automatically after signup
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name,avatar_url,phone) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','طالب MIS Career Hub'),new.raw_user_meta_data->>'avatar_url',new.phone); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- AFTER YOUR FIRST ACCOUNT IS CREATED, run this once with your email:
-- update public.profiles set role='owner' where id=(select id from auth.users where email='YOUR_EMAIL');
