// Copy this file to /supabase/config.js and add ONLY your public project values.
// Never put service_role / secret keys in browser code.
window.MIS_SUPABASE_CONFIG={
  url:"https://YOUR-PROJECT.supabase.co",
  anonKey:"YOUR-PUBLISHABLE-OR-ANON-KEY"
};
